# Control de Matrículas · Politécnico ASDI

Tablero web para gestionar metas de matrícula y medir el avance comercial por asesor. Conserva el diseño y la lógica del documento original, con los colores institucionales de ASDI.

## Archivos

| Archivo | Función |
| --- | --- |
| `index.html` | Estructura del tablero y ventanas de configuración. |
| `assets/css/styles.css` | Diseño, colores, barras de avance y adaptación a pantallas pequeñas. |
| `assets/js/app.js` | Cálculos, asesores, configuración, almacenamiento y exportación CSV. |
| `.nojekyll` | Permite servir directamente los archivos estáticos. |
| `.gitignore` | Excluye archivos temporales y variables de entorno. |
| `.gitattributes` | Normaliza los finales de línea del repositorio. |

## Abrir el tablero

Abre `index.html` en un navegador moderno. No requiere instalación, compilación, dependencias externas ni servidor.

Para probarlo con un servidor local, desde esta carpeta ejecuta:

```bash
python3 -m http.server 8000
```

Después abre `http://localhost:8000`.

## Subir a GitHub

1. Descomprime el ZIP.
2. Crea un repositorio en tu cuenta de GitHub, por ejemplo `control-matriculas-asdi`.
3. Sube **el contenido de esta carpeta** a la raíz del repositorio. `index.html` debe quedar en la raíz, con la carpeta `assets` a su lado. No subas solamente el ZIP.
4. Confirma los archivos en la rama principal.
5. Si quieres una dirección web, configura GitHub Pages para publicar desde la raíz de la rama principal. GitHub mostrará la dirección cuando la publicación termine.

También puedes subirlo con Git, desde esta carpeta:

```bash
git init
git add .
git commit -m "Organizar tablero de matrículas ASDI"
git branch -M main
git remote add origin https://github.com/TU-USUARIO/control-matriculas-asdi.git
git push -u origin main
```

Reemplaza `TU-USUARIO` y el nombre del repositorio por los tuyos. Estos comandos presuponen un repositorio remoto vacío y acceso configurado a tu cuenta.

## Funciones conservadas

- Crear, editar y eliminar asesores.
- Registrar metas y matrículas logradas.
- Buscar y ordenar asesores.
- Consultar cumplimiento, brecha, proyección y matrículas necesarias por día.
- Configurar meta general, fechas, días efectivos, festivos y receso.
- Ajustar indicadores, decimales, título y subtítulo.
- Exportar resultados en CSV y reiniciar la configuración.

## Cómo se guardan los datos

Los datos se guardan en `localStorage`, con la clave original `poli_matriculas_v1`. Cada navegador y dirección web tiene su propio almacenamiento: no existe sincronización entre computadores ni entre integrantes del equipo. El repositorio no recibe las matrículas registradas en el navegador.

Al pasar del archivo local a GitHub Pages, los datos guardados anteriormente no se trasladan automáticamente. La exportación CSV sirve como reporte; este tablero no incorpora importación ni restauración desde CSV. Borrar los datos del navegador o reiniciar el tablero elimina los registros locales.

## Mantenimiento

Edita `styles.css` para cambiar la apariencia y `app.js` para modificar el comportamiento. Los valores iniciales están en el objeto `defaults`; la configuración guardada en el navegador tiene prioridad sobre ellos.

La separación de archivos conserva la lógica original, incluidos sus criterios de cálculo. Este proyecto es una aplicación estática sin autenticación ni base de datos compartida.
