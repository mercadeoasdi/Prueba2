const KEY='poli_matriculas_v1';
const defaults={
  goal:815,
  start:'2026-10-05',
  end:'2027-01-15',
  breakStart:'2026-12-15',
  breakEnd:'2027-01-03',
  holidays:['2026-10-12','2026-11-02','2026-11-16','2026-12-08','2027-01-11'],
  workdays:[1,2,3,4,6],
  warnTolerance:8,
  projectionWarn:85,
  goodMargin:5,
  decimals:1,
  showRules:true,
  title:'Control de Matrículas',
  subtitle:'Politécnico ASDI · Meta comercial 2026–2027',
  advisors:[]
};
const stored=JSON.parse(localStorage.getItem(KEY)||'null');
let state={...defaults,...(stored||{}),advisors:Array.isArray(stored?.advisors)?stored.advisors:[]};
if(!Array.isArray(state.workdays)) state.workdays=[1,2,3,4,6];
let editId=null;

function save(){localStorage.setItem(KEY,JSON.stringify(state));render()}
function d(s){if(!s)return null;let [y,m,day]=s.split('-').map(Number);return new Date(y,m-1,day)}
function isoLocal(x){const y=x.getFullYear(),m=String(x.getMonth()+1).padStart(2,'0'),day=String(x.getDate()).padStart(2,'0');return `${y}-${m}-${day}`}
function effective(dateStr){
  const x=d(dateStr); if(!x)return false;
  const day=x.getDay();
  if(!state.workdays.includes(day))return false;
  if(state.holidays.includes(dateStr))return false;
  if(state.breakStart&&state.breakEnd&&dateStr>=state.breakStart&&dateStr<=state.breakEnd)return false;
  return dateStr>=state.start&&dateStr<=state.end;
}
function daysBetween(a,b){let count=0;let x=d(a),end=d(b);if(!x||!end)return 0;for(;x<=end;x.setDate(x.getDate()+1)){let s=isoLocal(x);if(effective(s))count++}return count}
function todayClamped(){let now=new Date(),s=isoLocal(now);if(s<state.start)return state.start;if(s>state.end)return state.end;return s}
function metrics(a){
  const today=todayClamped(), total=daysBetween(state.start,state.end), elapsed=daysBetween(state.start,today);
  const remaining=Math.max(0,total-elapsed);
  const should=a.goal*(elapsed/Math.max(total,1));
  const pct=a.goal?a.done/a.goal*100:0;
  const pace=elapsed?a.done/elapsed:0;
  const projection=Math.min(999999,a.done+pace*remaining);
  const projPct=a.goal?projection/a.goal*100:0;
  const need=remaining>0?Math.max(0,(a.goal-a.done)/remaining):Math.max(0,a.goal-a.done);
  return {total,elapsed,remaining,should,pct,pace,projection,projPct,need};
}
function fmt(n){return Math.round(Number(n)||0).toLocaleString('es-CO')}
function pct(n){return Number(n||0).toLocaleString('es-CO',{minimumFractionDigits:state.decimals,maximumFractionDigits:state.decimals})+'%'}
function status(m){
  const expectedPct=m.goal?m.should/m.goal*100:0;
  if(m.pct>=Math.min(100,expectedPct+state.goodMargin)||m.pct+0.01>=expectedPct)return ['En ritmo','good'];
  if(m.pct>=expectedPct-state.warnTolerance)return ['Atención','warn'];
  return ['Atrasado','bad'];
}
function esc(s){return String(s).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
function dayNames(days){const names={0:'domingo',1:'lunes',2:'martes',3:'miércoles',4:'jueves',5:'viernes',6:'sábado'};return days.slice().sort((a,b)=>a-b).map(x=>names[x]).join(', ')}

function render(){
  document.getElementById('pageTitle').textContent=state.title||defaults.title;
  document.getElementById('pageSubtitle').textContent=state.subtitle||defaults.subtitle;
  document.getElementById('rulesNote').style.display=state.showRules?'flex':'none';
  const receso=state.breakStart&&state.breakEnd?` También se excluye el receso del ${state.breakStart} al ${state.breakEnd}.`:'';
  const holidays=state.holidays.length?` Hay ${state.holidays.length} festivo(s) configurado(s).`:'';
  document.getElementById('rulesText').textContent=`cuentan ${dayNames(state.workdays)}.${holidays}${receso}`;

  document.getElementById('kMeta').textContent=fmt(state.goal);
  const done=state.advisors.reduce((s,a)=>s+Number(a.done||0),0);
  const total=daysBetween(state.start,state.end),elapsed=daysBetween(state.start,todayClamped()),remaining=Math.max(0,total-elapsed);
  document.getElementById('kDone').textContent=fmt(done);
  document.getElementById('kDoneSub').textContent=state.goal?pct(done/state.goal*100)+' de la meta':'—';
  document.getElementById('kDays').textContent=remaining;
  document.getElementById('kDaySub').textContent=`${elapsed} días efectivos transcurridos de ${total}`;
  document.getElementById('kRate').textContent=remaining?fmt(Math.ceil(Math.max(0,state.goal-done)/remaining)):'0';
  document.getElementById('headerStatus').textContent=remaining>0?`${remaining} días efectivos restantes`:'Periodo finalizado';

  renderRows();

  const projected=state.advisors.reduce((s,a)=>s+metrics(a).projection,0);
  const gap=state.goal-done;
  const individualGoals=state.advisors.reduce((s,a)=>s+Number(a.goal||0),0);
  document.getElementById('summary').innerHTML=`Hoy <b>${todayClamped()}</b>. Han transcurrido <b>${elapsed}</b> días efectivos y quedan <b>${remaining}</b>. Faltan <b>${fmt(Math.max(0,gap))}</b> matrículas para alcanzar la meta general. La proyección actual del equipo es de <b>${fmt(projected)}</b> matrículas.`;
  document.getElementById('summaryChips').innerHTML=`
    <div class="metric-chip">Metas individuales<b>${fmt(individualGoals)}</b></div>
    <div class="metric-chip">Brecha general<b>${fmt(Math.max(0,gap))}</b></div>
    <div class="metric-chip">Proyección del equipo<b>${fmt(projected)}</b></div>`;
}

function renderRows(){
  const tbody=document.getElementById('rows'); if(!tbody)return;
  const q=(document.getElementById('searchInput')?.value||'').trim().toLowerCase();
  const sort=document.getElementById('sortSelect')?.value||'name';
  let list=state.advisors.filter(a=>a.name.toLowerCase().includes(q));
  list=list.slice().sort((a,b)=>{
    const ma=metrics(a),mb=metrics(b);
    if(sort==='goal-desc')return b.goal-a.goal;
    if(sort==='done-desc')return b.done-a.done;
    if(sort==='pct-desc')return mb.pct-ma.pct;
    if(sort==='need-desc')return mb.need-ma.need;
    return a.name.localeCompare(b.name,'es');
  });
  tbody.innerHTML='';
  if(!list.length){tbody.innerHTML=`<tr><td colspan="10" class="empty"><strong>${state.advisors.length?'No hay coincidencias':'Aún no hay asesores'}</strong>${state.advisors.length?'Prueba con otro nombre.':'Agrega el primero para comenzar a medir el avance.'}</td></tr>`;return}
  list.forEach(a=>{
    const m=metrics(a),st=status(m),fill=Math.min(100,m.pct),projClass=m.projPct>=100?'good':m.projPct>=state.projectionWarn?'warn':'bad';
    const tr=document.createElement('tr');
    tr.innerHTML=`
      <td><div class="name">${esc(a.name)}</div><div class="status-line"><span class="status-dot ${st[1]}"></span>${st[0]}</div></td>
      <td class="num"><b>${fmt(a.goal)}</b></td>
      <td><input class="inline-input" type="number" min="0" value="${Number(a.done||0)}" onchange="updateDone('${a.id}',this.value)"></td>
      <td class="num">${fmt(m.should)}</td>
      <td><div class="progress-wrap"><div class="progress-top"><span class="progress-percent">${pct(m.pct)}</span><span class="small">de ${fmt(a.goal)}</span></div><div class="progress-track"><div class="progress-fill ${st[1]}" style="width:${fill}%"></div></div></div></td>
      <td class="num">${m.should-a.done>0?`<span class="badge bad">−${fmt(m.should-a.done)}</span>`:`<span class="badge good">+${fmt(a.done-m.should)}</span>`}</td>
      <td class="num">${fmt(m.projection)}</td>
      <td><span class="badge ${projClass}">${pct(m.projPct)}</span></td>
      <td class="num"><b>${fmt(Math.ceil(m.need))}</b><span class="small"> / día</span></td>
      <td><div class="row-actions"><button class="btn btn-secondary btn-icon" title="Editar" onclick="editAdvisor('${a.id}')">✎</button><button class="btn btn-danger btn-icon" title="Eliminar" onclick="deleteAdvisor('${a.id}')">×</button></div></td>`;
    tbody.appendChild(tr);
  });
}

function openAdvisor(){editId=null;['aName','aGoal','aDone'].forEach(x=>document.getElementById(x).value='');document.getElementById('advisorTitle').textContent='Agregar asesor';document.getElementById('advisorModal').classList.add('open')}
function editAdvisor(id){let a=state.advisors.find(x=>x.id===id);if(!a)return;editId=id;aName.value=a.name;aGoal.value=a.goal;aDone.value=a.done;advisorTitle.textContent='Editar asesor';advisorModal.classList.add('open')}
function saveAdvisor(){let name=aName.value.trim(),goal=Number(aGoal.value||0),done=Number(aDone.value||0);if(!name||goal<0)return alert('Ingresa un nombre y una meta válida.');if(editId){let a=state.advisors.find(x=>x.id===editId);Object.assign(a,{name,goal,done})}else state.advisors.push({id:(crypto.randomUUID?crypto.randomUUID():String(Date.now())),name,goal,done});closeModal();save()}
function updateDone(id,v){let a=state.advisors.find(x=>x.id===id);if(a){a.done=Math.max(0,Number(v)||0);save()}}
function deleteAdvisor(id){if(confirm('¿Eliminar este asesor?')){state.advisors=state.advisors.filter(a=>a.id!==id);save()}}

function openSettings(){
  sGoal.value=state.goal;sStart.value=state.start;sEnd.value=state.end;sBreakStart.value=state.breakStart||'';sBreakEnd.value=state.breakEnd||'';sHolidays.value=state.holidays.join(', ');
  sWarnTolerance.value=state.warnTolerance;sProjectionWarn.value=state.projectionWarn;sGoodMargin.value=state.goodMargin;sDecimals.value=state.decimals;sShowRules.checked=!!state.showRules;sTitle.value=state.title||defaults.title;sSubtitle.value=state.subtitle||defaults.subtitle;
  [0,1,2,3,4,5,6].forEach(day=>document.getElementById('d'+day).checked=state.workdays.includes(day));
  switchTab('general',document.querySelector('.tab-btn[data-tab="general"]'));
  settingsModal.classList.add('open');
}
function saveSettings(){
  const workdays=[0,1,2,3,4,5,6].filter(day=>document.getElementById('d'+day).checked);
  if(!sStart.value||!sEnd.value)return alert('Define la fecha de inicio y la fecha límite.');
  if(sStart.value>sEnd.value)return alert('La fecha de inicio no puede ser posterior a la fecha límite.');
  if(!workdays.length)return alert('Selecciona al menos un día efectivo.');
  state.goal=Math.max(0,Number(sGoal.value||0));state.start=sStart.value;state.end=sEnd.value;state.breakStart=sBreakStart.value;state.breakEnd=sBreakEnd.value;
  state.holidays=sHolidays.value.split(',').map(x=>x.trim()).filter(Boolean);state.workdays=workdays;
  state.warnTolerance=Math.max(0,Number(sWarnTolerance.value||0));state.projectionWarn=Math.max(0,Number(sProjectionWarn.value||0));state.goodMargin=Math.max(0,Number(sGoodMargin.value||0));
  state.decimals=Math.min(2,Math.max(0,Number(sDecimals.value||0)));state.showRules=sShowRules.checked;state.title=sTitle.value.trim()||defaults.title;state.subtitle=sSubtitle.value.trim()||defaults.subtitle;
  closeModal();save();
}
function switchTab(name,btn){document.querySelectorAll('.tab-panel').forEach(x=>x.classList.remove('active'));document.querySelectorAll('.tab-btn').forEach(x=>x.classList.remove('active'));document.getElementById('tab-'+name).classList.add('active');btn?.classList.add('active')}
function closeModal(){document.querySelectorAll('.modal').forEach(x=>x.classList.remove('open'))}
function resetAll(){if(confirm('Esto borrará asesores y configuración guardada. ¿Continuar?')){localStorage.removeItem(KEY);location.reload()}}
function exportCSV(){
  let head=['Asesor','Meta','Logrado','Debería llevar','Cumplimiento %','Brecha','Proyección','Cumplimiento proyectado %','Necesario por día'];
  let lines=[head.join(';')];state.advisors.forEach(a=>{let m=metrics(a);lines.push([a.name,a.goal,a.done,Math.round(m.should),m.pct.toFixed(1),Math.round(a.done-m.should),Math.round(m.projection),m.projPct.toFixed(1),Math.ceil(m.need)].join(';'))});
  let blob=new Blob(['\ufeff'+lines.join('\n')],{type:'text/csv;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='control_matriculas_asdi.csv';a.click();URL.revokeObjectURL(url)
}

document.addEventListener('keydown',e=>{if(e.key==='Escape')closeModal()});
document.querySelectorAll('.modal').forEach(m=>m.addEventListener('click',e=>{if(e.target===m)closeModal()}));
render();
